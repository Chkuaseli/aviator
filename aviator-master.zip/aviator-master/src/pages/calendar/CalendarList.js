const calendar = [
  {
    id: "name01",
    name: "name01",
    month: "September",
    day: "30",
    year: "2020",
    text:
      "lorem ipus lorem ipusma koko, lorem ipus lorem ipusma koko,lorem ipus lorem ipusma koko.lorem ipus lorem ipusma koko.lorem ipus lorem ipusma koko"
  },
  {
    id: "name02",
    name: "name02",
    month: "October",
    day: "5",
    year: "2020",
    text:
      "lorem ipus lorem ipusma koko, lorem ipus lorem ipusma koko,lorem ipus lorem ipusma koko.lorem ipus lorem ipusma koko.lorem ipus lorem ipusma koko"
  },
  {
    id: "name03",
    name: "name03",
    month: "October",
    day: "15",
    year: "2020",
    text:
      "lorem ipus lorem ipusma koko, lorem ipus lorem ipusma koko,lorem ipus lorem ipusma koko.lorem ipus lorem ipusma koko.lorem ipus lorem ipusma koko"
  },
  {
    id: "name04",
    name: "name04",
    month: "November",
    day: "7",
    year: "2020",
    text:
      "lorem ipus lorem ipusma koko, lorem ipus lorem ipusma koko,lorem ipus lorem ipusma koko.lorem ipus lorem ipusma koko.lorem ipus lorem ipusma koko"
  }
];

export default calendar;
