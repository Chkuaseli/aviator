import Project01 from "../../images/Project01.jpg";
import Project02 from "../../images/Project02.jpg";
import Project03 from "../../images/Project03.jpg";

// img: link to firebase storage (not realtime database)

const projects = [
  {
    id: "project1",
    name: "project01",
    img: Project01,
    subTitle: "project 01 subTitle",
    text:
      "lorem ipsam img simmg kmkmm dsnjnjn, lorem ipsam img simmg kmkmm dsnjnjn lorem ipsam img simmg kmkmm dsnjnjn lorem ipsam img simmg kmkmm dsnjnjn lorem ipsam img simmg kmkmm dsnjnjn lorem ipsam img simmg kmkmm dsnjnjn lorem ipsam img simmg kmkmm dsnjnjn lorem ipsam img simmg kmkmm dsnjnjn,lorem ipsam img simmg kmkmm dsnjnjn"
  },
  {
    id: "project2",
    name: "project02",
    img: Project02,
    subTitle: "project 02 subTitle",
    text:
      "lorem ipsam img simmg kmkmm dsnjnjn,lorem ipsam img simmg kmkmm dsnjnjn lorem ipsam img simmg kmkmm dsnjnjn "
  },
  {
    id: "project4",
    name: "project03",
    img: Project03,
    subTitle: "project 03 subTitle",
    text:
      "lorem ipsam img simmg kmkmm dsnjnjn lorem ipsam img simmg kmkmm dsnjnjn lorem ipsam img simmg kmkmm dsnjnjn"
  }
  // {
  //   id: "project4",
  //   name: "project04",
  //   img: Project03,
  //   subTitle: "project 04 subTitle",
  //   text:
  //     "lorem ipsam img simmg kmkmm dsnjnjn lorem ipsam img simmg kmkmm dsnjnjn lorem ipsam img simmg kmkmm dsnjnjn",
  // }
];

export default projects;
