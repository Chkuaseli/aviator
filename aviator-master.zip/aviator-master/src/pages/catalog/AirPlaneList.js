import Plane01 from "../../images/plane01.jpg";
import Plane02 from "../../images/plane02.jpg";
import Plane03 from "../../images/plane03.jpg";
import Plane04 from "../../images/plane04.jpg";

const airPlane = [
  {
    name: "P-51 Mustang",
    id: "pl01",
    img: Plane01,
    text:
      "This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer."
  },
  {
    name: "Private Jet",
    id: "pl02",
    img: Plane02,
    text:
      "This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer."
  },
  {
    name: "Carenado Aircraft to 10.30",
    id: "pl03",
    img: Plane03,
    text:
      "This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer."
  },
  {
    name: "Beechcraft Bonanza Model 35",
    id: "pl04",
    img: Plane04,
    text:
      "This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer."
  }
];

export default airPlane;
