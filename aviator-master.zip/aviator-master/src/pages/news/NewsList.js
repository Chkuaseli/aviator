import Project01 from "../../images/Project01.jpg";
import Project02 from "../../images/Project02.jpg";
import Project03 from "../../images/Project03.jpg";
// import Project04 from "../images/Project04.jpg";

const news = [
  {
    id: "news01",
    name: "News1",
    title: "Special title treatment01",
    text:
      "lokok kokfdokf kf nnjnjk okdoksok ksdok so dfnjsddnf  msdmf ofof kodkfpo ks oijfojs on lksmdfjs ij ksjdfj sf j osjgo sjof j jspgjsjg oi",
    img: Project01,
  },
  {
    id: "news02",
    name: "News2",
    title: "Special title treatment02",
    text:
      "lokok kokfdokf kf nnjnjk okdoksok ksdok so dfnjsddnf  msdmf ofof kodkfpo ks oijfojs on lksmdfjs ij ksjdfj sf j osjgo sjof j jspgjsjg oi",
    img: Project02,
  },
  {
    id: "news03",
    name: "News3",
    title: "Special title treatment03",
    text:
      "lokok kokfdokf kf nnjnjk okdoksok ksdok so dfnjsddnf  msdmf ofof kodkfpo ks oijfojs on lksmdfjs ij ksjdfj sf j osjgo sjof j jspgjsjg oi",
    img: Project03,
  },
  // {
  //   id: "news04",
  //   name: "News4",
  //   title: "Special title treatment04",
  //   text:
  //     "lokok kokfdokf kf nnjnjk okdoksok ksdok so dfnjsddnf  msdmf ofof kodkfpo ks oijfojs on lksmdfjs ij ksjdfj sf j osjgo sjof j jspgjsjg oi",
  //   // img: Project04,
  // }
];

export default news;
