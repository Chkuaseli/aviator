import React from "react";
import "./SearchResults.styles.css";

class searchResults extends React.Component {
  render() {
    return <div id="container"></div>;
  }
}

export default searchResults;
