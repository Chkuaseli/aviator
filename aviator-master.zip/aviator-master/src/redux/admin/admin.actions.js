export const logAdmin = adminObj => ({
    type: "SET_ADMIN_MODE",
    payload: adminObj
});