export const setDate = dateObj => ({
    type: "SET_DATE",
    payload: dateObj
});


// export const setDate = (day, month, year, text)=> ({
//     type: "SET_DATE",
//     payload: {
//         day,
//         month,
//         year,
//         text
//     }
// });